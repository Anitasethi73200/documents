<?php

namespace App\Http\Controllers;
use App\Models\Task;
use App\Models\User;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;

class UsermanageController extends Controller
{
    public function index(){
        // dd(Hash::make('12345'));
        return view('user');
    }

    public function loginuser(Request $request)
    {
           $request->validate([
             'email' =>'required|email',
             'password'=>'required',
           ]);
           $user = User::where('email',$request->email)->first();

           if(!$user){
                return redirect()->route('index')->with('error','invalid email or password');
           }
           $credentials = $request->only('email','password');
           if (Auth::attempt($credentials)){
               return redirect()->route('getuser');
           }else{
             return redirect()->route('index')->with('error','invalid email or password');
           }
    }
    public function getuser(){
        // $decryptedId = Crypt::decryptString($id);
        $task = Task::all();
        $user = User::all();
        return view('taskdata', compact('user', 'task'));
    }

    public function update_status(Request $request)
    {
        $task = Task::find($request->task_id);
        if ($task) {
            $task->status = $request->status;
            $task->save();
            return response()->json(['success' => true,'message' => 'Enquiry update  successfuly']);
        } else {
            return response()->json(['success' => false, 'message' => 'Enquiry not found'], 404);
        }
    }
    public function user_task(){

          return view('task');
    }

    public function user_post(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required',
            'description' => 'required',
            'file' => 'nullable|file',
        ]);

        if ($validator->passes()) {
            try{
                $task = new Task();
                $task->title = $request->title;
                $task->description = $request->description;
                if ($request->hasFile('file')) {
                    $ext = $request->file('file')->getClientOriginalExtension();
                    $newFileName = time() . '.' . $ext;
                    $request->file('file')->move(public_path('/uploads/task/'), $newFileName);
                    $task->file = $newFileName;
                }
                $task->save();
            }catch(Error $err){
                console.log($err);
            }
            return redirect()->route('getuser')->with('success', 'Record added successfully.');

        } else {
            return redirect()->back()->with('error', 'Enter Validate');
        }
    }

    public function assigntask(Request $request, $taskId)
    {
        $request->validate([
            'assigned_user_id' => 'required',
        ]);

        $decryptedTaskId = Crypt::decryptString($taskId);
        $task = Task::find($decryptedTaskId);
        if (!$task) {
            return response()->json(['error' => 'Task not found'], 404);
        }
        $userId = $request->input('assigned_user_id');
        Task::find($decryptedTaskId)->update([
            'assigned_user_id' => $userId
        ]);

        return response()->json(['message' => 'User assigned to task successfully'], 200);
    }

    public function edittask($id){
        $id = Crypt::decryptString($id);
        $task= Task::find($id);
        return view('edittask',compact('task'));
    }

  public function updatetask($id,Request $request){ {
    $validator = Validator::make($request->all(), [
        'title' => 'required',
        'description' => 'required',
    ]);

    if ($validator->passes()) {
        try{
            $task =Task ::find($id);
            $task->title = $request->title;
            $task->description = $request->description;
            $task->save();
        }catch(Error $err){
            console.log($err);
        }
        return redirect()->route('getuser')->with('success', 'Record update successfully.');

    } else {
        return redirect()->back()->with('error', 'Enter Validate');
    }
}
   }
   public function deletetask($id){
    $id = Crypt::decryptString($id);
    $task = Task::find($id);
    if ($task) {
        $task->delete();
        return redirect()->route('getuser')->with('success', 'Task deleted successfully');
    } else {
        return redirect()->route('getuser')->with('error', 'Task not found');
    }
}
 public function comment()
 {
       return view('comments');
 }


public function postcomment(Request $request)
{
    $request->validate([
        'content' => 'required',
        'task_id' => 'required',
    ]);

    $comment = new Comment([
        'content' => $request->input('content'),
        'task_id' => $request->input('task_id'),
        'user_id' => Auth::id(),
    ]);
    $comment->save();
    dd($comment);

    return redirect()->back()->with('success', 'Comment added successfully!');
}


}
