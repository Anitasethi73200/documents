<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 30px;
            color: #333;
        }

        .login-form input[type="email"],
        .login-form input[type="password"] {
            width: calc(100% - 24px);
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        .login-form button[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #04AA6D;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .login-form button[type="submit"]:hover {
            background-color: #087f52;
        }

        .login-form label {
            font-size: 14px;
        }

        .login-form .form-footer {
            margin-top: 20px;
            font-size: 14px;
        }

        .login-form .form-footer a {
            color: #04AA6D;
            text-decoration: none;
        }

        .login-form .form-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>Login Form</h2>
        <form class="login-form" action="{{ route('loginuser') }}" method="post">
            @csrf
            <input type="email" placeholder="Enter Email" name="email" required>
            <input type="password" placeholder="Enter Password" name="password" required>
            <button type="submit">Login</button>
            <label>
                <input type="checkbox" checked="checked" name="remember"> Remember me
            </label>
            <div class="form-footer">
                <a href="#">Forgot password?</a>
            </div>
        </form>
    </div>
</body>

</html>
