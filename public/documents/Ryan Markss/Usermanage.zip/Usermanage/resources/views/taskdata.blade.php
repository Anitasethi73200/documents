<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Task List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom Styles */
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header {
            border-bottom: none;
        }

        .modal-title {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="mb-4">Task List</h2>
        <div class="action-buttons mb-3">
            <a href="{{ route('user_task') }}" class="btn btn-success">Add Task</a>
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Action</th>
                    <th>Assign User</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($task as $data)
                <tr>
                    <td>{{ $data->id }}</td>
                    <td>{{ $data->title }}</td>
                    <td>{{ $data->description }}</td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input toggle-status" type="checkbox" role="switch"
                                id="flexSwitchCheckDefault-{{ $data->id }}"
                                data-task-status="{{ $data->status }}" data-task-id="{{ $data->id }}"
                                {{ $data->status == 'done' ? 'checked' : '' }}>
                            <label class="form-check-label" for="flexSwitchCheckDefault-{{ $data->id }}"></label>
                        </div>
                    </td>
                    <td>
                        <a href="{{ route('edittask', ['id' => Crypt::encryptString($data->id)]) }}"
                            class="btn btn-sm btn-primary">Edit</a>
                        <a href="{{ route('deletetask', ['id' => Crypt::encryptString($data->id)]) }}"
                            class="btn btn-sm btn-danger">Delete</a>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-success assign-agent" data-task-id="{{ $data->id }}"
                            data-toggle="modal" data-target="#exampleModal">Assign User</button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <!-- Assign User Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="assignUserForm">
                        @csrf
                        <input type="hidden" name="task_id" id="task_id">
                        <div class="form-group">
                            <label for="assigned_user_id">Select User:</label>
                            <select class="form-control" id="assigned_user_id" name="assigned_user_id">
                                @foreach ($user as $data)
                                <option value="{{ $data->id }}">{{ $data->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Assign Task</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Custom Script -->
    <script>
        $(document).ready(function () {
            // Toggle task status
            $('.toggle-status').change(function () {
                const taskStatus = $(this).attr('data-task-status');
                var status = (taskStatus == 'done') ? 'pending' : 'done';
                var task_id = $(this).data('task-id');
                $.ajax({
                    type: "GET",
                    dataType: "json",
                    url: 'update-status',
                    data: {
                        'status': status,
                        'task_id': task_id,
                    },
                    success: function (data) {
                        console.log('success');
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });


            $('.assign-agent').click(function () {
                $('#task_id').val($(this).data('task-id'));
            });
            $('#assignUserForm').submit(function (e) {
                e.preventDefault();

                const formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: `${window.location.origin}/taskassign/${$('#task_id').val()}`,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        console.log(response)
                        window.location.reload();
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>

</html>
