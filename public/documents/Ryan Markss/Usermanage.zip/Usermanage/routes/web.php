<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsermanageController;
use App\Http\Controllers\ContactController;


Route::get('/',[UsermanageController::class,'index'])->name('index');
Route::post('/login',[UsermanageController::class,'loginuser'])->name('loginuser');
Route::get('/getuser',[UsermanageController::class,'getuser'])->name('getuser');
Route::get('/update-status',[UsermanageController::class, 'update_status'])->name('update_status');
Route::get('/usertask',[UsermanageController::class,'user_task'])->name('user_task');
Route::post('/userpost',[UsermanageController::class,'user_post'])->name('userpost');
Route::get('edittask/{id}',[UsermanageController::class,'edittask'])->name('edittask');
Route::post('updatetask/{id}',[UsermanageController::class,'updatetask'])->name('updatetask');
Route::get('deletetask/{id}',[UsermanageController::class,'deletetask'])->name('deletetask');
Route::get('/comment',[UsermanageController::class,'comment'])->name('comment');
Route::post('/postcomment',[UsermanageController::class,'postcomment'])->name('postcomment');
Route::post('/taskassign/{taskId}', [UsermanageController::class, 'assigntask'])->name('assigntask');

