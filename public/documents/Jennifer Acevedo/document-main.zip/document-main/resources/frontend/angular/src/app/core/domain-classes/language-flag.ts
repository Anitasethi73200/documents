export interface LanguageFlag {
    code: string;
    name: string;
    imageUrl: string;
    active?: boolean;
  }