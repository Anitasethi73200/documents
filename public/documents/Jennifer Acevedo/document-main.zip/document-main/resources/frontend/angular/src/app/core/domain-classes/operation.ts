export interface Operation {
    id?: string;
    name: string;
}
