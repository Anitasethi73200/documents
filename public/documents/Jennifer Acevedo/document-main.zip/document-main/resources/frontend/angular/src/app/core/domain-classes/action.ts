export class Action {
  id?: string;
  name: string;
  pageId?: string;
  order?: number;
  code: string;
}
