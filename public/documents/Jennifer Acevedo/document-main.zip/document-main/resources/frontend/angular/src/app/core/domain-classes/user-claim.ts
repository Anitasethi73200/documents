export class UserClaim {
  userId?: string;
  claimType: string;
  claimValue: string;
  actionId: string;
}
