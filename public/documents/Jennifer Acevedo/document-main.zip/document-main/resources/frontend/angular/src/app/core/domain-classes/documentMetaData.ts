export interface DocumentMetaData {
    id?: string;
    documentId?: string;
    metatag?: string;
  }