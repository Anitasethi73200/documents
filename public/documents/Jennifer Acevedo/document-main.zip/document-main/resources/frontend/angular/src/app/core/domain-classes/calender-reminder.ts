export class CalenderReminderDto {
    start: Date;
    end: Date;
    title: string;
}