export class RoleClaim {
  roleId?: string;
  claimType: string;
  claimValue: string;
  actionId: string;
}
