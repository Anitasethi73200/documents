export class ResponseHeader {
    totalCount: number = 0;
    pageSize: number = 0;
    skip: number = 0;
    totalPages: number = 0;
  }