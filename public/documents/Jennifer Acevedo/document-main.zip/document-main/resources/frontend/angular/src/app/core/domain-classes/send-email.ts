export interface SendEmail {
  subject: string;
  message: string;
  documentId: string;
  email: string;
}
