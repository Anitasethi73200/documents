export class ReminderUsers {
    reminderId: string;
    userId: string;
}