export class UserRoles {
    userId: string;
    roleId: string
    userName?: string;
    firstName?: string;
    lastName?: string;
}